@echo off
cd /d "%~dp0"
start "SCHOOL LIFE 3D V8.3" http://localhost:7555
py -m http.server 7555 --bind 127.0.0.1
pause
