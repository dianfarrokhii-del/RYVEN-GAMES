import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const $=id=>document.getElementById(id), fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const loader=new GLTFLoader();
const load=u=>new Promise((res,rej)=>loader.load(u,res,undefined,rej));
function repairCityMaterials(root){root.traverse(o=>{if(!o.isMesh)return; const mats=Array.isArray(o.material)?o.material:[o.material]; mats.forEach(m=>{if(!m)return; if(m.map){m.map.colorSpace=THREE.SRGBColorSpace; m.map.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8); m.map.needsUpdate=true;} if(m.emissiveMap)m.emissiveMap.colorSpace=THREE.SRGBColorSpace; if(m.vertexColors)m.vertexColors=false; m.needsUpdate=true;}); o.castShadow=true;o.receiveShadow=true;o.frustumCulled=true;});}
const saveKey='schoolLife3D_V86';
const DAYS=['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه'];
const SCHEDULE={
 'شنبه':['ریاضی','فارسی','ورزش'],
 'یکشنبه':['انگلیسی','اجتماعی','ریاضی'],
 'دوشنبه':['علوم','فارسی','ورزش'],
 'سه‌شنبه':['ریاضی','انگلیسی','هنر'],
 'چهارشنبه':['اجتماعی','علوم','فارسی']
};
const LESSONS={
 'ریاضی':[
  {title:'ضرب و محاسبه سریع',text:'امروز درباره ضرب عددهای ساده می‌خوانیم. مثلاً ۱۰ × ۱۰ برابر با ۱۰۰ است. وقتی یکی از عددها ۱۰ باشد، می‌توانیم یک صفر به عدد دیگر اضافه کنیم.',books:['ریاضی','فارسی','عربی','علوم']},
  {title:'کسرها',text:'کسر یک قسمت از یک کل است. در کسر، عدد بالا صورت و عدد پایین مخرج نام دارد. برای مقایسه کسرها باید به مخرج‌ها و صورت‌ها دقت کنیم.',books:['علوم','ریاضی','اجتماعی','انگلیسی']},
  {title:'عددهای صحیح',text:'عددهای مثبت، منفی و صفر روی محور اعداد قرار می‌گیرند. عددی که سمت راست‌تر باشد، بزرگ‌تر است.',books:['ریاضی','هنر','فارسی','علوم']}
 ],
 'فارسی':[
  {title:'جمله و فعل',text:'در فارسی، فعل نشان می‌دهد چه کاری انجام شده یا چه حالتی وجود دارد. با پیدا کردن فعل، بخش مهمی از جمله را بهتر می‌فهمیم.',books:['فارسی','ریاضی','عربی','اجتماعی']},
  {title:'واژه‌های هم‌خانواده',text:'کلمه‌های هم‌خانواده ریشه مشترک دارند. پیدا کردن ریشه به ما کمک می‌کند معنی واژه‌های تازه را سریع‌تر بفهمیم.',books:['علوم','فارسی','انگلیسی','ریاضی']}
 ],
 'علوم':[
  {title:'ماده و حالت‌های آن',text:'ماده می‌تواند جامد، مایع یا گاز باشد. یخ جامد، آب مایع و بخار آب گاز است و با تغییر دما می‌توان حالت ماده را تغییر داد.',books:['علوم','ریاضی','فارسی','هنر']},
  {title:'نیرو و حرکت',text:'نیرو می‌تواند حرکت جسم را شروع، متوقف یا تغییر دهد. هل دادن و کشیدن نمونه‌هایی از وارد کردن نیرو هستند.',books:['اجتماعی','علوم','عربی','ریاضی']}
 ],
 'انگلیسی':[
  {title:'معرفی خودمان',text:'عبارت‌های ساده مثل I am a student برای معرفی خودمان کاربرد دارند. امروز چند جمله کوتاه می‌خوانیم و معنی آن‌ها را یاد می‌گیریم.',books:['انگلیسی','ریاضی','فارسی','علوم']},
  {title:'روزهای هفته',text:'Saturday, Sunday, Monday و بقیه روزهای هفته را مرور می‌کنیم و با آن‌ها جمله‌های ساده می‌سازیم.',books:['فارسی','انگلیسی','هنر','اجتماعی']}
 ],
 'اجتماعی':[
  {title:'جامعه و همکاری',text:'مدرسه یک جامعه کوچک است. همکاری، رعایت قانون و احترام به دیگران باعث می‌شود کارها بهتر پیش بروند.',books:['اجتماعی','علوم','ریاضی','فارسی']},
  {title:'شهر و خدمات',text:'مدرسه، بیمارستان، آتش‌نشانی و حمل‌ونقل از خدمات مهم شهر هستند و هرکدام وظیفه مشخصی دارند.',books:['ریاضی','اجتماعی','انگلیسی','هنر']}
 ],
 'هنر':[
  {title:'رنگ و ترکیب',text:'رنگ‌های اصلی می‌توانند برای ساخت رنگ‌های تازه ترکیب شوند. در طراحی، هماهنگی رنگ‌ها روی حس تصویر اثر می‌گذارد.',books:['هنر','ریاضی','علوم','فارسی']}
 ],
 'ورزش':[
  {title:'فوتبال و همکاری تیمی',text:'امروز در ورزش روی پاس دادن، حرکت بدون توپ و همکاری تیمی تمرکز می‌کنیم. بعد از تدریس کوتاه، مسابقه سه به سه داریم.',books:['ورزش','ریاضی','علوم','فارسی']}
 ]
};
const EXAM_BANK={
 'ریاضی':[
  {q:'۱۰ × ۱۰ چند می‌شود؟',o:['۱۰','۱۰۰','۱۰۰۰','۲۰'],a:1},{q:'کدام عدد بزرگ‌تر است؟',o:['-2','-5','-8','-10'],a:0}
 ],
 'فارسی':[{q:'کدام گزینه فعل دارد؟',o:['کتاب خوب','من می‌خوانم','مدرسه بزرگ','دوست خوب'],a:1}],
 'علوم':[{q:'آب در حالت جامد چیست؟',o:['بخار','یخ','هوا','نمک'],a:1}],
 'انگلیسی':[{q:'کدام جمله برای معرفی خود درست است؟',o:['I am a student.','Student I am?','I student are.','Am I student.'],a:0}],
 'اجتماعی':[{q:'کدام مورد یک خدمت شهری است؟',o:['آتش‌نشانی','مداد','دفتر','توپ'],a:0}],
 'هنر':[{q:'کدام مورد به ترکیب رنگ مربوط است؟',o:['رنگ‌آمیزی','تقسیم','ضرب','دویدن'],a:0}]
};
let state=Object.assign({day:0,period:0,phase:'morning',time:480,quality:'high',grades:{},examHistory:[],termHistory:[],homework:[],lessonCount:0,weeklyDone:false},JSON.parse(localStorage.getItem(saveKey)||'{}'));
const save=()=>localStorage.setItem(saveKey,JSON.stringify(state));
const canvas=$('c');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.shadowMap.autoUpdate=true;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x9bd7f5);scene.fog=new THREE.Fog(0x9bd7f5,48,180);
const cam=new THREE.PerspectiveCamera(58,1,.05,350);function resize(){renderer.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}addEventListener('resize',resize);resize();
const hemi=new THREE.HemisphereLight(0xeaf7ff,0x496044,1.55);scene.add(hemi);const sun=new THREE.DirectionalLight(0xfff3d7,3);sun.castShadow=true;sun.shadow.mapSize.set(3072,3072);sun.shadow.camera.left=-60;sun.shadow.camera.right=60;sun.shadow.camera.top=60;sun.shadow.camera.bottom=-60;sun.shadow.camera.near=1;sun.shadow.camera.far=180;scene.add(sun);scene.add(sun.target);const fill=new THREE.DirectionalLight(0xbfdcff,.65);fill.position.set(-30,20,30);scene.add(fill);
function quality(q){state.quality=q;const d={low:1,medium:Math.min(devicePixelRatio,1.75),high:Math.min(devicePixelRatio,2.5)}[q]||2;renderer.setPixelRatio(d);sun.shadow.mapSize.setScalar(q==='high'?3072:q==='medium'?1536:768);save()}
const yard=new THREE.Group();scene.add(yard);const colliders=[];const mat=(c,r=.72,m=.05)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
function box(w,h,d,x,y,z,c,solid=true){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c,.78));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;yard.add(m);if(solid)colliders.push({x,z,hx:w/2,hz:d/2});return m}
const ground=new THREE.Mesh(new THREE.PlaneGeometry(180,180),mat(0x5caa57,.95));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;yard.add(ground);
// School exterior/courtyard replaces the old placeholder school.
let soccerField=null,schoolField=null,football=null;
// Keep the school at the exact location previously occupied by the old school.
const SCHOOL_CENTER=new THREE.Vector3(0,0,-20);
// The original supplied football stadium remains separate and is not replaced.
const SOCCER_CENTER=new THREE.Vector3(22,0,10);
const fieldClampX0=SOCCER_CENTER.x-12,fieldClampX1=SOCCER_CENTER.x+12,fieldClampZ0=SOCCER_CENTER.z-7,fieldClampZ1=SOCCER_CENTER.z+7;
async function loadOptionalAssets(){
  try{
    const g=await load('assets/models/school_exterior.glb');
    schoolField=g.scene;
    let b=new THREE.Box3().setFromObject(schoolField),s=b.getSize(new THREE.Vector3());
    schoolField.scale.setScalar(50/Math.max(s.x,s.z));
    b=new THREE.Box3().setFromObject(schoolField);
    const c=b.getCenter(new THREE.Vector3());
    // The source GLB has hidden/vertical geometry extending below the courtyard.
    // Its actual courtyard/grass plane is at source Y=0, so do NOT use the
    // overall bounding-box minimum (that would lift the whole school into the air).
    schoolField.position.set(SCHOOL_CENTER.x-c.x,0.02,SCHOOL_CENTER.z-c.z);
    schoolField.traverse(o=>{if(o.isMesh){repairCityMaterials(o);o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false}});
    yard.add(schoolField);
  }catch(e){console.warn('school exterior asset failed',e)}
  // Keep the original supplied soccer stadium as the actual football pitch.
  try{
    const g=await load('assets/models/soccer_field.glb');
    soccerField=g.scene;
    let b=new THREE.Box3().setFromObject(soccerField),s=b.getSize(new THREE.Vector3());
    soccerField.scale.setScalar(26/Math.max(s.x,s.z));
    b=new THREE.Box3().setFromObject(soccerField);
    soccerField.position.set(SOCCER_CENTER.x,-b.min.y+0.02,SOCCER_CENTER.z);
    soccerField.traverse(o=>{if(o.isMesh){repairCityMaterials(o);o.castShadow=true;o.receiveShadow=true}});
    yard.add(soccerField);
  }catch(e){console.warn('soccer field asset failed',e)}
  try{
    const g=await load('assets/models/football.glb');
    football=g.scene;
    let b=new THREE.Box3().setFromObject(football),s=b.getSize(new THREE.Vector3());
    football.scale.setScalar(.7/Math.max(s.x,s.y,s.z));
    b=new THREE.Box3().setFromObject(football);
    football.position.set(SOCCER_CENTER.x,Math.max(.12,-b.min.y+.04),SOCCER_CENTER.z);
    yard.add(football);football.traverse(o=>{if(o.isMesh)o.castShadow=true});
  }catch(e){}
}
function primitiveFallback(kind='player'){const p=new THREE.Group(),bodyMat=mat(kind==='player'?0x2563eb:0x2d3748,.62),skin=mat(0xd8a47f,.82),dark=mat(0x172033,.7);const body=new THREE.Mesh(new THREE.CapsuleGeometry(.31,.72,8,16),bodyMat);body.position.y=.82;body.castShadow=true;p.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.29,20,16),skin);head.position.y=1.62;head.castShadow=true;p.add(head);const hair=new THREE.Mesh(new THREE.SphereGeometry(.30,20,12,0,Math.PI*2,0,Math.PI*.48),dark);hair.position.y=1.72;hair.castShadow=true;p.add(hair);for(const x of [-.22,.22]){const a=new THREE.Mesh(new THREE.CylinderGeometry(.085,.10,.62,10),bodyMat);a.position.set(x,.84,0);a.rotation.z=x>0?-.12:.12;a.castShadow=true;p.add(a);const l=new THREE.Mesh(new THREE.CylinderGeometry(.105,.12,.72,10),dark);l.position.set(x*.65,.25,0);l.castShadow=true;p.add(l);const shoe=new THREE.Mesh(new THREE.BoxGeometry(.23,.11,.42),mat(0xf4f4f2,.45));shoe.position.set(x*.65,.03,.07);shoe.castShadow=true;p.add(shoe)}p.scale.setScalar(.695);return {pivot:p,phase:0,real:false}}
function normalizeCharacter(g,targetHeight=1.39){const root=new THREE.Group(),model=g.scene.clone(true);root.add(model);let b=new THREE.Box3().setFromObject(model),size=b.getSize(new THREE.Vector3());const s=targetHeight/Math.max(size.y,.001);model.scale.setScalar(s);b=new THREE.Box3().setFromObject(model);const c=b.getCenter(new THREE.Vector3());model.position.x-=c.x;model.position.z-=c.z;model.position.y-=b.min.y;model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false}});return root}
let tomCharacterTemplate=null;async function loadTomCharacter(){try{const g=await load('assets/models/tom_casual_school_uniform.glb');tomCharacterTemplate=normalizeCharacter(g);return true}catch(e){return false}}
function makeCharacter(kind='player'){if(kind==='player'&&tomCharacterTemplate){const p=tomCharacterTemplate.clone(true);return {pivot:p,phase:0,real:true,mixer:null}}return primitiveFallback(kind)}
const input={keys:{},yaw:0,pitch:.28,dist:5.4,joyX:0,joyY:0,run:false,act:false};addEventListener('keydown',e=>{input.keys[e.code]=true;if(e.code==='KeyE')input.act=true;if(e.code==='Escape'&&!$('modal').hidden)closeModal()});addEventListener('keyup',e=>input.keys[e.code]=false);$('mobileRun').addEventListener('pointerdown',()=>input.run=true);['pointerup','pointercancel'].forEach(ev=>$('mobileRun').addEventListener(ev,()=>input.run=false));$('speedBtn').onclick=()=>{input.run=!input.run;$('speedBtn').textContent=input.run?'🏃‍♂️':'🏃'};
let drag=null;canvas.addEventListener('pointerdown',e=>{drag={id:e.pointerId,x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;input.yaw-=(e.clientX-drag.x)*.006;input.pitch=THREE.MathUtils.clamp(input.pitch+(e.clientY-drag.y)*.005,-.1,1.05);drag.x=e.clientX;drag.y=e.clientY});canvas.addEventListener('pointerup',()=>drag=null);canvas.addEventListener('pointercancel',()=>drag=null);canvas.addEventListener('wheel',e=>input.dist=THREE.MathUtils.clamp(input.dist+e.deltaY*.005,3,8));
const joy=$('joy'),knob=$('knob');let jid=null;function joySet(e){const r=joy.getBoundingClientRect(),dx=(e.clientX-(r.left+r.width/2))/50,dy=(e.clientY-(r.top+r.height/2))/50,l=Math.hypot(dx,dy);input.joyX=l>1?dx/l:dx;input.joyY=l>1?-dy/l:-dy;knob.style.transform=`translate(${input.joyX*35}px,${-input.joyY*35}px)`}joy.addEventListener('pointerdown',e=>{jid=e.pointerId;joy.setPointerCapture(jid);joySet(e)});joy.addEventListener('pointermove',e=>{if(e.pointerId===jid)joySet(e)});function joyEnd(){jid=null;input.joyX=input.joyY=0;knob.style.transform=''}joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
let player,tom,teacher,room,roomB,mode='yard',busy=false,seat=null,lessonActive=false;const pos=new THREE.Vector3(-24,0,24),P={yaw:-0.5754,r:.48};function collide(p,cs,r){for(const c of cs){const dx=p.x-c.x,dz=p.z-c.z,ox=c.hx+r-Math.abs(dx),oz=c.hz+r-Math.abs(dz);if(ox>0&&oz>0){if(ox<oz)p.x+=Math.sign(dx||1)*ox;else p.z+=Math.sign(dz||1)*oz}}}
function pose(a,moving,dt,speed){if(!a)return;if(moving){a.phase+=dt*speed*3;if(!a.real){for(let i=0;i<a.pivot.children.length;i++){const ch=a.pivot.children[i];if(i>=5&&i<=8)ch.rotation.x=Math.sin(a.phase+(i%2)*Math.PI)*.35}}else{a.pivot.position.y=Math.sin(a.phase*2)*.025;a.pivot.rotation.z=Math.sin(a.phase)*.018}}}
function say(t){$('objective').textContent=t}
function schoolTime(){const h=Math.floor(state.time/60)%24,m=Math.floor(state.time%60);$('clock').textContent=fa(String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'))}
function score(){let a=0,b=0;for(const g of Object.values(state.grades)){a+=g.total||0;b+=g.count||0}return b?Math.round(a/b*10)/10:0}
function closeModal(){if(lessonActive)return;const modal=$('modal');modal.hidden=true;modal.style.display='none';busy=false;input.act=false;$('act').hidden=true;$('box').innerHTML=''}
function show(html){$('box').innerHTML=`<div class="modalHead"><div></div><button class="x" id="modalClose">✕</button></div><div id="modalContent">${html}</div>`;$('modal').hidden=false;$('modal').style.display='grid';busy=true;const x=$('modalClose');if(x)x.onclick=e=>{e.stopPropagation();closeModal()}}
function settings(){show(`<h2>⚙️ تنظیمات</h2><p>کیفیت، صدا و کنترل‌ها</p>${[['low','کم'],['medium','متوسط'],['high','بالا']].map(x=>`<button class="setting ${state.quality===x[0]?'active':''}" data-q="${x[0]}"><b>${x[1]}</b></button>`).join('')}<div class="soundBox"><b>🔊 صدای بازی</b><input id="gameVolume" type="range" min="0" max="100" value="70"><span id="volumeValue">۷۰٪</span><button class="setting" id="soundTest"><b>🔔 تست صدا</b><span>برای بررسی صدای بازی</span></button></div><div class="info">💻 حرکت: WASD / فلش‌ها<br>🏃 سرعت: دکمه 🏃 یا Shift<br>🖱️ دوربین: کشیدن موس<br>⌨️ تعامل: E</div><button class="ok" data-close>بستن</button>`);$('box').querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>{quality(b.dataset.q);settings()});const vol=$('gameVolume'),vv=$('volumeValue');vol.oninput=()=>{vv.textContent=fa(vol.value)+'٪';localStorage.setItem('schoolLifeVolume',vol.value)};const savedVol=localStorage.getItem('schoolLifeVolume');if(savedVol){vol.value=savedVol;vv.textContent=fa(savedVol)+'٪'}$('soundTest').onclick=()=>{try{const C=window.AudioContext||window.webkitAudioContext,c=new C(),o=c.createOscillator(),g=c.createGain();g.gain.value=(vol.value/100)*.08;o.frequency.value=660;o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.12)}catch(e){}};$('box').querySelector('[data-close]').onclick=closeModal}
function about(){show('<h2>🏫 SCHOOL LIFE 3D — V8.5</h2><div class="info">یک هفته مدرسه از شنبه تا چهارشنبه؛ کلاس، تدریس، استراحت، تکلیف، امتحان و فوتبال سه به سه.</div><button class="ok" data-close>بستن</button>');$('box').querySelector('[data-close]').onclick=closeModal}
function dayName(){return DAYS[state.day]||DAYS[0]}function currentSubject(){return (SCHEDULE[dayName()]||[])[state.period]||'ریاضی'}
function scheduleUI(){const rows=DAYS.map((d,i)=>`<tr><th>${d}</th>${SCHEDULE[d].map((s,j)=>`<td>${s}${i===state.day&&j===state.period?' ⭐':''}</td>`).join('')}</tr>`).join('');show(`<h2>📅 برنامه هفتگی</h2><div class="info">مدرسه: شنبه تا چهارشنبه | پنجشنبه و جمعه تعطیل<br>ساعت مدرسه: ۰۸:۰۰ تا ۱۳:۰۰<br>هر روز ۳ زنگ</div><table><tr><th>روز</th><th>زنگ ۱</th><th>زنگ ۲</th><th>زنگ ۳</th></tr>${rows}</table><button class="ok" data-close>بستن</button>`);$('box').querySelector('[data-close]').onclick=closeModal}
function reportUI(){const subjects=Object.entries(state.grades);const body=subjects.length?subjects.map(([s,g])=>`<tr><td>${s}</td><td>${g.count}</td><td>${(g.total/g.count).toFixed(1)}</td></tr>`).join(''):'<tr><td colspan="3">هنوز نمره‌ای ثبت نشده</td></tr>';show(`<h2>📋 کارنامه</h2><div class="info">میانگین کارنامه: <b>${fa(score())}</b></div><table><tr><th>درس</th><th>تعداد نمره</th><th>میانگین</th></tr>${body}</table><button class="ok" data-close>بستن</button>`);$('box').querySelector('[data-close]').onclick=closeModal}
function examHistoryUI(){const body=state.examHistory.length?state.examHistory.slice().reverse().map(x=>`<tr><td>${x.day}</td><td>${x.subject}</td><td>${x.score}/${x.total}</td></tr>`).join(''):'<tr><td colspan="3">هنوز امتحانی نداده‌ای</td></tr>';show(`<h2>📝 تاریخچه امتحانات</h2><table><tr><th>روز</th><th>درس</th><th>نمره</th></tr>${body}</table><button class="ok" data-close>بستن</button>`);$('box').querySelector('[data-close]').onclick=closeModal}
async function enterClass(){
  if(currentSubject()==='ورزش'){
    mode='yard'; yard.visible=true; if(room) room.visible=false;
    pos.set(SOCCER_CENTER.x,0,SOCCER_CENTER.z-8); P.yaw=0; input.yaw=0; input.pitch=.28; input.dist=5.4;
    busy=false; $('act').hidden=true;
    say('🏃 زنگ ورزش! مستقیم به زمین فوتبال منتقل شدی.');
    setTimeout(()=>football3v3(),500);
    return;
  }
  busy=true;say('⏳ ورود به کلاس…');if(!room){try{const g=await Promise.race([load('assets/models/japanese_classroom.glb'),new Promise((_,rej)=>setTimeout(()=>rej(0),3500))]);const m=g.scene;let b=new THREE.Box3().setFromObject(m),sz=b.getSize(new THREE.Vector3());m.scale.setScalar(12/Math.max(sz.x,sz.z));b=new THREE.Box3().setFromObject(m);const c=b.getCenter(new THREE.Vector3());m.position.set(500-c.x,-b.min.y,-c.z);room=new THREE.Group();room.add(m);scene.add(room);b=new THREE.Box3().setFromObject(m);roomB={x0:b.min.x+.8,x1:b.max.x-.8,z0:b.min.z+.8,z1:b.max.z-.8}}catch(e){room=new THREE.Group();scene.add(room);const floor=new THREE.Mesh(new THREE.BoxGeometry(20,.2,15),mat(0xbcae96,.9));floor.position.set(500,0,0);room.add(floor);const wall=new THREE.Mesh(new THREE.BoxGeometry(20,7,.3),mat(0xe8dfd1,.9));wall.position.set(500,3.5,-7);room.add(wall);roomB={x0:490,x1:510,z0:-6,z1:7}}teacher=makeCharacter('teacher');teacher.pivot.position.set(500,0,roomB.z0+1.4);room.add(teacher.pivot);tom=makeCharacter('friend');tom.pivot.position.set(502,0,roomB.z0+3);room.add(tom.pivot);seat=new THREE.Vector3(500,0,roomB.z1-3)}mode='room';yard.visible=false;room.visible=true;scene.fog.far=350;pos.copy(seat);P.yaw=Math.PI;input.yaw=Math.PI;input.pitch=.18;input.dist=4;busy=false;say(`📚 ${currentSubject()} — به سمت صندلی برو و E بزن`)}
function leaveClass(){mode='yard';if(room)room.visible=false;yard.visible=true;scene.fog.far=155;pos.set(0,0,-8);P.yaw=0;input.yaw=0;input.pitch=.28;input.dist=5.4;say('🌳 زنگ تفریح — یک دقیقه استراحت کن')}
function lessonData(){const arr=LESSONS[currentSubject()]||LESSONS['ریاضی'];return arr[(state.day*3+state.period)%arr.length]}
function bookSelect(){const l=lessonData();show(`<h2>👨‍🏫 ${currentSubject()}</h2><p>معلم: «کتاب ${currentSubject()} رو باز کنید.»</p><div class="bookGrid">${l.books.map((b,i)=>`<button class="book" data-book="${b}">📖 ${b}</button>`).join('')}</div>`);$('box').querySelectorAll('[data-book]').forEach(b=>b.onclick=()=>{if(b.dataset.book!==currentSubject()){show(`<h2>⚠️ اشتباهه!</h2><p>معلم: «گفتم کتاب ${currentSubject()} رو باز کنید. دوباره انتخاب کن.»</p><button class="ok" id="retryBook">انتخاب دوباره</button>`);$('retryBook').onclick=bookSelect}else{startTeaching(l)}})}
function teachingSegments(subject,l){
  const banks={
    'ریاضی':[
      'اگر دو عدد مثبت را جمع کنیم، حاصل از هر کدام بزرگ‌تر یا مساوی است.',
      'برای مقایسه کسرهای هم‌مخرج، کسری که صورت بزرگ‌تری دارد بزرگ‌تر است.',
      'اگر یک عدد را در صفر ضرب کنیم، حاصل همیشه صفر می‌شود.',
      'در عبارت ۳ + ۴ × ۲، ابتدا ضرب انجام می‌شود و بعد جمع؛ پس جواب ۱۱ است.',
      'عدد قرینهٔ ۵، عدد منفی ۵ است و فاصله هر دو از صفر برابر است.',
      'برای ساده کردن کسر، صورت و مخرج را بر یک عدد مشترک تقسیم می‌کنیم.',
      'محیط مستطیل برابر مجموع چهار ضلع آن است؛ یعنی ۲ × (طول + عرض).',
      'مساحت مستطیل از ضرب طول در عرض به دست می‌آید.',
      'اگر مخرج دو کسر برابر باشد، مقایسه صورت‌ها مقایسه خود کسرها را مشخص می‌کند.',
      'تقریب زدن قبل از محاسبه کمک می‌کند بفهمیم جواب نهایی منطقی است یا نه.',
      'در محور اعداد، هرچه به سمت راست برویم عددها بزرگ‌تر می‌شوند.',
      'درصد یعنی بخشی از صد؛ مثلاً ۲۵ درصد یعنی ۲۵ قسمت از ۱۰۰ قسمت.'
    ],
    'فارسی':[
      'فعل کلمه‌ای است که انجام کار یا رخ دادن یک حالت را نشان می‌دهد.',
      'در جمله «دانش‌آموز کتاب را خواند»، واژه «خواند» فعل جمله است.',
      'نهاد معمولاً کسی یا چیزی است که درباره آن خبری می‌دهیم یا کاری را انجام می‌دهد.',
      'در جمله «علی فوتبال بازی کرد»، «علی» نهاد و «بازی کرد» فعل است.',
      'واژه‌های هم‌خانواده معمولاً ریشه مشترک دارند؛ مثل دانش، دانشمند و دانشگاه.',
      'مترادف واژه‌ای است که معنایی نزدیک به واژه دیگر دارد؛ مثل شاد و خوشحال.',
      'متضادها معنی مخالف دارند؛ مثل روشن و تاریک.',
      'برای فهم متن، اول موضوع اصلی را پیدا کن و بعد سراغ جزئیات برو.',
      'جمله خبری معمولاً اطلاعاتی درباره یک موضوع به ما می‌دهد.',
      'نشانه «؟» معمولاً در پایان جمله پرسشی می‌آید.',
      'در خواندن یک متن، توجه به عنوان می‌تواند سرنخی درباره موضوع اصلی بدهد.',
      'برای بهتر نوشتن، جمله‌ها را کوتاه، روشن و از نظر فعل و نهاد هماهنگ نگه دار.'
    ],
    'علوم':[
      'ماده سه حالت رایج دارد: جامد، مایع و گاز.',
      'در جامد، ذرات به هم نزدیک‌ترند و شکل مشخص‌تری دیده می‌شود.',
      'مایع حجم مشخص دارد اما شکل ظرف را می‌گیرد.',
      'گاز شکل و حجم ثابتی ندارد و فضای ظرف را پر می‌کند.',
      'ذوب شدن یعنی تبدیل جامد به مایع، مثل تبدیل یخ به آب.',
      'تبخیر یعنی تبدیل مایع به گاز؛ خشک شدن لباس نمونه‌ای از آن است.',
      'میعان یا چگالش یعنی تبدیل گاز به مایع، مثل تشکیل قطره روی سطح سرد.',
      'نیرو می‌تواند سرعت یا جهت حرکت جسم را تغییر دهد.',
      'اصطکاک نیرویی است که معمولاً با حرکت دو سطح روی هم مخالفت می‌کند.',
      'در یک آزمایش علمی بهتر است فقط یک عامل را تغییر دهیم و نتیجه را مقایسه کنیم.',
      'مشاهده، اندازه‌گیری و ثبت داده‌ها به ما کمک می‌کنند نتیجه علمی دقیق‌تری بگیریم.',
      'گرما می‌تواند باعث تغییر دما یا تغییر حالت بعضی مواد شود.'
    ],
    'انگلیسی':[
      'برای گفتن «من دانش‌آموز هستم» می‌گوییم: I am a student.',
      'I یعنی «من» و you یعنی «تو یا شما».',
      'He برای یک پسر یا مرد و she برای یک دختر یا زن به کار می‌رود.',
      'برای معرفی یک دوست می‌توان گفت: He is my friend.',
      'برای پرسیدن نام کسی می‌توان گفت: What is your name?',
      'پاسخ ساده به آن سؤال می‌تواند این باشد: My name is Tom.',
      'روزهای هفته در انگلیسی با حرف بزرگ نوشته می‌شوند؛ مثل Monday و Saturday.',
      'This یعنی «این» و that یعنی «آن».',
      'برای گفتن «من فوتبال دوست دارم» می‌توان گفت: I like football.',
      'در جمله ساده انگلیسی معمولاً فاعل پیش از فعل می‌آید.',
      'am با I و is با he، she و it در جمله‌های پایه استفاده می‌شود.',
      'برای جمع بستن بسیاری از اسم‌ها در انگلیسی از s استفاده می‌کنیم؛ مثل book و books.'
    ],
    'اجتماعی':[
      'جامعه از افرادی تشکیل می‌شود که در کنار هم زندگی می‌کنند و با هم ارتباط دارند.',
      'قانون برای ایجاد نظم و مشخص کردن حقوق و مسئولیت‌ها به وجود می‌آید.',
      'همکاری یعنی چند نفر برای رسیدن به یک هدف مشترک با هم کار کنند.',
      'شهروندان علاوه بر حقوق، مسئولیت‌هایی مثل رعایت قوانین و احترام به دیگران دارند.',
      'شهرداری یکی از نهادهایی است که در اداره و خدمات شهری نقش دارد.',
      'آتش‌نشانی، اورژانس و حمل‌ونقل نمونه‌هایی از خدمات موردنیاز شهروندان هستند.',
      'منابع طبیعی مانند آب و خاک باید درست مصرف و حفظ شوند.',
      'نقشه برای نشان دادن مکان‌ها و ارتباط بین آن‌ها از دیدی ساده‌شده استفاده می‌کند.',
      'مقیاس نقشه نشان می‌دهد فاصله روی نقشه چه نسبتی با فاصله واقعی دارد.',
      'احترام به نظر دیگران یکی از پایه‌های گفت‌وگوی سالم است.',
      'تقسیم وظایف می‌تواند باعث شود یک کار گروهی سریع‌تر و منظم‌تر انجام شود.',
      'تصمیم‌گیری بهتر زمانی انجام می‌شود که اطلاعات کافی و چند گزینه را بررسی کنیم.'
    ],
    'هنر':[
      'رنگ‌های اصلی در آموزش پایه معمولاً قرمز، زرد و آبی معرفی می‌شوند.',
      'با ترکیب رنگ‌ها می‌توان رنگ‌های تازه‌ای به دست آورد.',
      'رنگ‌های گرم مثل قرمز و نارنجی معمولاً حس انرژی بیشتری ایجاد می‌کنند.',
      'رنگ‌های سرد مثل آبی و سبز می‌توانند حس آرامش بیشتری ایجاد کنند.',
      'خط می‌تواند برای نشان دادن شکل، جهت و حرکت در یک تصویر استفاده شود.',
      'اندازه و جای هر عنصر روی تعادل کلی یک طرح اثر می‌گذارد.',
      'تضاد بین روشن و تیره می‌تواند بخش مهمی از تصویر را بیشتر نشان دهد.',
      'تکرار یک شکل یا الگو می‌تواند در تصویر نظم و ریتم ایجاد کند.',
      'قبل از شروع یک نقاشی، مشخص کردن موضوع و ترکیب‌بندی به نظم کار کمک می‌کند.',
      'بافت در هنر به ظاهر یا حس سطح یک ماده در تصویر اشاره می‌کند.',
      'فضای خالی هم بخشی از طراحی است و می‌تواند باعث خواناتر شدن تصویر شود.',
      'خلاقیت فقط به نقاشی محدود نیست؛ انتخاب ایده و شیوه بیان آن هم بخشی از خلاقیت است.'
    ],
    'ورزش':[
      'در فوتبال، پاس کوتاه وقتی دقیق‌تر است که بدن و پای ضربه‌زننده رو به هم‌تیمی باشد.',
      'قبل از دریافت توپ، یک نگاه سریع به اطراف کمک می‌کند تصمیم بهتری بگیری.',
      'حرکت بدون توپ می‌تواند برای هم‌تیمی فضای خالی ایجاد کند.',
      'در دفاع تیمی، نزدیک بودن بازیکنان به هم پوشش دادن فضا را آسان‌تر می‌کند.',
      'کنترل اول توپ یعنی دریافت توپ به شکلی که برای حرکت بعدی آماده باشی.',
      'پاس دادن به بازیکن آزاد معمولاً می‌تواند حفظ توپ را برای تیم آسان‌تر کند.',
      'در دویدن ورزشی، گرم کردن بدن قبل از فعالیت شدید به آماده شدن عضلات کمک می‌کند.',
      'تعادل بدن هنگام تغییر جهت سریع، کنترل حرکت را بهتر می‌کند.',
      'در بازی تیمی، ارتباط کلامی کوتاه می‌تواند به هماهنگی بازیکنان کمک کند.',
      'بعد از فعالیت بدنی، استراحت و نوشیدن آب به ریکاوری بدن کمک می‌کند.',
      'در فوتبال، دیدن فضای خالی قبل از حرکت می‌تواند تصمیم‌گیری را سریع‌تر کند.',
      'جمع‌بندی ورزش: کنترل توپ، حرکت بدون توپ، پاس و همکاری چهار مهارت مهم امروز هستند.'
    ]
  };
  const pool=banks[subject]||[];
  const first=`موضوع امروز: «${l.title}». ${l.text}`;
  const rest=pool.filter(x=>!first.includes(x));
  for(let i=rest.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[rest[i],rest[j]]=[rest[j],rest[i]]}
  return [first,...rest.slice(0,5)];
}

function startTeaching(l){
  lessonActive=true;
  if(window._lessonTimer) clearInterval(window._lessonTimer);
  const segments=teachingSegments(currentSubject(),l);
  let remain=90, lastSegment=-1;
  const renderLesson=()=>{
    const elapsed=90-remain, idx=Math.min(segments.length-1,Math.floor(elapsed/15));
    const mm=String(Math.floor(remain/60)).padStart(2,'0'), ss=String(remain%60).padStart(2,'0');
    const progress=Math.round((elapsed/90)*100);
    $('lessonTimer').textContent=`${mm}:${ss}`;
    $('lessonProgress').style.width=`${progress}%`;
    $('lessonPart').textContent=`بخش ${fa(idx+1)} از ${fa(segments.length)}`;
    $('lessonText').textContent=segments[idx];
    if(idx!==lastSegment){lastSegment=idx;$('lessonHint').textContent=idx===segments.length-1?'آخرین بخش — جمع‌بندی درس':'معلم: «آروم و با دقت بخونید؛ نکته بعدی چند ثانیه دیگه میاد.»';}
  };
  show(`<h2>📚 ${currentSubject()} — ${l.title}</h2>
    <div class="info"><b>⏱️ زمان باقی‌مانده: <span id="lessonTimer">01:30</span></b></div>
    <div class="lessonProgress"><div id="lessonProgress"></div></div>
    <div class="lessonPart" id="lessonPart">بخش ۱ از ۶</div>
    <div class="lessonCard" id="lessonText"></div>
    <p id="lessonHint">معلم: «آروم و با دقت بخونید.»</p>`);
  const lessonClose=$('modalClose'); if(lessonClose) lessonClose.style.display='none';
  renderLesson();
  window._lessonTimer=setInterval(()=>{
    remain--;
    if(remain<=0){clearInterval(window._lessonTimer);window._lessonTimer=null;lessonActive=false;finishLesson(l);return;}
    renderLesson();
  },1000);
}
function finishLesson(l){state.lessonCount++;state.time+=3;save();const isSaturdayFootball=state.day===0&&state.period===2&&currentSubject()==='ورزش';show(`<h2>✅ درس تمام شد</h2><p>${currentSubject()} رو یاد گرفتی.</p><div class="info">حالا ${isSaturdayFootball?'به حیاط می‌رویم تا مسابقه سه به سه را شروع کنیم.':'یک استراحت کوتاه در حیاط داری.'}</div><button class="ok" id="toYard">🌳 رفتن به حیاط</button>`);$('toYard').onclick=()=>{closeModal();leaveClass();setTimeout(()=>{if(isSaturdayFootball){football3v3()}else nextPeriod()},1200)}}
function nextPeriod(){if(state.period<2){state.period++;state.phase='break';state.time+=1;save();say(`🔔 زنگ بعدی: ${SCHEDULE[dayName()][state.period]}`);setTimeout(()=>enterClass(),1200)}else{finishSchoolDay()}}
function homeworkForDay(){const next=DAYS[state.day+1];if(!next)return['مرور درس‌های هفته و استراحت برای تعطیلات.'];const s=SCHEDULE[next];return[`تمرین ${s[0]} برای فردا را مرور کن.`,`یک صفحه از ${s[1]} بخوان.`,`برای کلاس ${s[2]} آماده باش.`]}
function finishSchoolDay(){const hw=homeworkForDay();state.homework=hw;state.time=780;save();$('fade').style.opacity=1;setTimeout(()=>{$('fade').style.opacity=0;closeModal();if(state.day<4){state.day++;state.period=0;state.phase='morning';state.time=480;pos.set(-24,0,62);P.yaw=-0.5754;input.yaw=-0.5754;mode='yard';yard.visible=true;if(room)room.visible=false;say(`🌅 ${dayName()} — زنگ ۸ شروع شد؛ به مدرسه برو`);show(`<h2>🏠 پایان روز</h2><p>تکالیف فردا:</p><div class="info">${hw.map(x=>'• '+x).join('<br>')}</div><button class="ok" id="newDay">شروع روز بعد</button>`);$('newDay').onclick=()=>closeModal()}else{show(`<h2>🎉 هفته مدرسه تمام شد</h2><div class="info">پنجشنبه و جمعه تعطیل! هفته بعد دوباره از شنبه شروع می‌شود.</div><button class="ok" id="newWeek">شروع شنبه هفته بعد</button>`);$('newWeek').onclick=()=>{state.day=0;state.period=0;state.time=480;state.homework=[];save();closeModal();pos.set(-24,0,62);P.yaw=-0.5754;input.yaw=-0.5754;say('🌅 شنبه — زنگ ۸ شروع شد؛ در محوطه مدرسه هستی. آماده شروع روزی تازه‌ای')}}},2000)}
async function runExam(subject,term=false){const bank=EXAM_BANK[subject]||EXAM_BANK['ریاضی'];let i=0,c=0;function q(){if(i>=bank.length){const score=Math.round(c/bank.length*20);state.examHistory.push({day:dayName(),subject,score,total:20,term});if(!state.grades[subject])state.grades[subject]={total:0,count:0};state.grades[subject].total+=score;state.grades[subject].count++;if(term)state.termHistory.push({day:dayName(),subject,score});save();show(`<h2>📝 برگه امتحان</h2><div class="info">نمره ${subject}: <b>${fa(score)} از ۲۰</b><br>این نمره در تاریخچه امتحانات و کارنامه ثبت شد.</div><button class="ok" id="examDone">بازگشت</button>`);$('examDone').onclick=()=>{closeModal();say('📋 نمره ثبت شد')};return}const x=bank[i];show(`<h2>امتحان ${subject} — ${fa(i+1)} از ${fa(bank.length)}</h2><p>${x.q}</p>${x.o.map((o,n)=>`<button class="opt" data-e="${n}">${o}</button>`).join('')}`);$('box').querySelectorAll('[data-e]').forEach(b=>b.onclick=()=>{if(+b.dataset.e===x.a)c++;i++;q()})}q()}
function examsUI(){const subjects=[...new Set(Object.values(SCHEDULE).flat())];show(`<h2>📝 امتحان</h2><p>یک امتحان تمرینی انتخاب کن:</p>${subjects.map(s=>`<button class="opt" data-ex="${s}">${s}</button>`).join('')}<button class="ok" data-close>بستن</button>`);$('box').querySelectorAll('[data-ex]').forEach(b=>b.onclick=()=>runExam(b.dataset.ex,false));$('box').querySelector('[data-close]').onclick=closeModal}
let footballGame=null;
function football3v3(){
  if(footballGame)return;
  busy=false; mode='football'; yard.visible=true; if(room)room.visible=false;
  const arena=new THREE.Group(); scene.add(arena);
  const center=SOCCER_CENTER.clone(), fieldX0=center.x-12, fieldX1=center.x+12, fieldZ0=center.z-7, fieldZ1=center.z+7;
  const blue=[],red=[];
  const mkAI=(x,z,c)=>{const a=primitiveFallback('ai');a.pivot.scale.setScalar(.9);a.pivot.position.set(x,0,z);a.pivot.children.forEach(o=>{if(o.material){o.material=o.material.clone();if(o.material.color)o.material.color.set(c)}});arena.add(a.pivot);return {obj:a.pivot,home:new THREE.Vector3(x,0,z),team:c===0x2563eb?'blue':'red',cool:0}};
  blue.push(mkAI(center.x-6,center.z-4,0x2563eb),mkAI(center.x-6,center.z+4,0x2563eb));
  red.push(mkAI(center.x+6,center.z-4,0xdc3545),mkAI(center.x+6,center.z+4,0xdc3545),mkAI(center.x+7,center.z,0xdc3545));
  let ballObj;
  if(football){ballObj=football.clone(true);ballObj.scale.copy(football.scale);ballObj.position.set(center.x,.42,center.z);ballObj.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}})}
  else {ballObj=new THREE.Mesh(new THREE.SphereGeometry(.34,20,16),mat(0xffffff,.35));ballObj.position.set(center.x,.34,center.z)}
  arena.add(ballObj);
  pos.set(center.x-6,0,center.z); P.yaw=Math.PI/2; input.yaw=Math.PI/2; input.pitch=.22; input.dist=6;
  const ballVel=new THREE.Vector3(); let scoreA=0,scoreB=0,last=performance.now(),start=last,duration=180000;
  const ui=document.createElement('div'); ui.id='footballHUD'; ui.innerHTML=`<div class="fbTop"><b>⚽ فوتبال ۳ به ۳</b><span id="fbClock">۳:۰۰</span><span id="fbScore2">۰ - ۰</span></div><div class="fbHint">WASD حرکت • Shift دویدن • Space شوت • Q پاس</div><button id="fbLeave">ترک مسابقه</button>`;document.body.appendChild(ui);
  const leave=()=>{if(!footballGame)return;cancelAnimationFrame(footballGame.raf);footballGame.cleanup?.();arena.removeFromParent();ui.remove();footballGame=null;mode='yard';busy=false;pos.set(SOCCER_CENTER.x,0,SOCCER_CENTER.z+9);input.dist=5.4;interact();};
  $('fbLeave').onclick=leave;
  footballGame={arena,ballObj,ballVel,blue,red,raf:0};
  const resetBall=(dir=1)=>{ballObj.position.set(center.x,.42,center.z);ballVel.set(dir*1.2,0,(Math.random()-.5)*.8)};
  const kick=(power=7)=>{
    const dx=Math.sin(input.yaw), dz=Math.cos(input.yaw); const d=new THREE.Vector3(dx,0,dz).normalize();
    const near=ballObj.position.distanceTo(pos)<2.0;
    if(near){ballVel.copy(d.multiplyScalar(power));ballVel.y=1.7;}
  };
  const pass=()=>{if(ballObj.position.distanceTo(pos)<2.0){let targetAI=blue.reduce((a,b)=>a.obj.position.distanceTo(pos)<b.obj.position.distanceTo(pos)?a:b);const d=new THREE.Vector3(targetAI.obj.position.x-ballObj.position.x,0,targetAI.obj.position.z-ballObj.position.z).normalize();ballVel.copy(d.multiplyScalar(5.5));}};
  const key=(e)=>{if(mode!=='football')return;if(e.code==='Space'){e.preventDefault();kick(8)}if(e.code==='KeyQ')pass();};addEventListener('keydown',key);
  footballGame.cleanup=()=>removeEventListener('keydown',key);
  resetBall(1);
  const step=()=>{
    if(!footballGame)return;
    const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
    const rem=Math.max(0,duration-(now-start));
    $('fbClock').textContent=`${Math.floor(rem/60000)}:${String(Math.floor(rem/1000)%60).padStart(2,'0')}`;
    // Ball physics
    ballVel.y-=9.8*dt; ballObj.position.addScaledVector(ballVel,dt);
    if(ballObj.position.y<.36){ballObj.position.y=.36; if(Math.abs(ballVel.y)>.8)ballVel.y*=-.32;else ballVel.y=0;ballVel.x*=.985;ballVel.z*=.985}
    if(ballObj.position.z<fieldZ0+.35){ballObj.position.z=fieldZ0+.35;ballVel.z=Math.abs(ballVel.z)*.65}
    if(ballObj.position.z>fieldZ1-.35){ballObj.position.z=fieldZ1-.35;ballVel.z=-Math.abs(ballVel.z)*.65}
    // Player can dribble/kick by walking into the ball.
    const dist=ballObj.position.distanceTo(pos);
    if(dist<1.05 && ballVel.length()<3){const d=new THREE.Vector3(pos.x-ballObj.position.x,0,pos.z-ballObj.position.z).normalize();ballVel.x+=d.x*2.2;ballVel.z+=d.z*2.2}
    // AI chase / defend / shoot.
    const all=[...blue,...red]; all.forEach((a,i)=>{a.cool-=dt;const toBall=new THREE.Vector3(ballObj.position.x-a.obj.position.x,0,ballObj.position.z-a.obj.position.z);let targetP=a.home;
      if(toBall.length()<8 || (a.team==='red'&&ballObj.position.x>center.x) || (a.team==='blue'&&ballObj.position.x<center.x)) targetP=ballObj.position;
      const d=new THREE.Vector3(targetP.x-a.obj.position.x,0,targetP.z-a.obj.position.z);if(d.length()>.3){d.normalize();a.obj.position.addScaledVector(d,dt*(a.team==='red'?2.7:2.5));a.obj.rotation.y=Math.atan2(d.x,d.z)}
      if(a.obj.position.distanceTo(ballObj.position)<1.05&&a.cool<=0){const dir=a.team==='red'?new THREE.Vector3(-1,0,(10-ballObj.position.z)*.06):new THREE.Vector3(1,0,(10-ballObj.position.z)*.06);ballVel.copy(dir.normalize().multiplyScalar(4.8));ballVel.y=1.1;a.cool=1.0}
    });
    // Goals at the two ends of the supplied stadium field.
    if(ballObj.position.x<fieldX0){scoreB++;$('fbScore2').textContent=`${fa(scoreA)} - ${fa(scoreB)}`;resetBall(1)}
    if(ballObj.position.x>fieldX1){scoreA++;$('fbScore2').textContent=`${fa(scoreA)} - ${fa(scoreB)}`;resetBall(-1)}
    // Keep ball inside the playable pitch unless it is crossing a goal line.
    if(ballObj.position.x<fieldX0-2){ballObj.position.x=fieldX0;ballVel.x=Math.abs(ballVel.x)}
    if(ballObj.position.x>fieldX1+2){ballObj.position.x=fieldX1;ballVel.x=-Math.abs(ballVel.x)}
    player.pivot.position.copy(pos);player.pivot.rotation.y=P.yaw;pose(player,true,dt,input.run?5:2.5);
    target.set(pos.x,1.15,pos.z);const cp=Math.cos(input.pitch),sp=Math.sin(input.pitch);desiredCam.set(target.x+Math.sin(input.yaw)*cp*input.dist,target.y+sp*input.dist+.25,target.z+Math.cos(input.yaw)*cp*input.dist);cam.position.lerp(desiredCam,1-Math.pow(.0008,dt));cam.lookAt(target);
    renderer.render(scene,cam);
    if(rem<=0){
      removeEventListener('keydown',key);ui.remove();footballGame=null;arena.removeFromParent();mode='yard';busy=true;
      show(`<h2>🏆 پایان مسابقه</h2><div class="info">نتیجه نهایی<br><b>آبی ${fa(scoreA)} - ${fa(scoreB)} قرمز</b><br><br>⏱️ سه دقیقه کامل بازی شد!</div><button class="ok" id="returnYard">↩️ بازگشت به حیاط</button>`);
      $('returnYard').onclick=()=>{closeModal();busy=false;pos.set(SOCCER_CENTER.x,0,SOCCER_CENTER.z+9);if(state.period<2)nextPeriod();else finishSchoolDay()};return;
    }
    footballGame.raf=requestAnimationFrame(step);
  };
  step();
}

function interact(){if(mode==='football'){return}if(mode==='yard'){const doorNear=pos.distanceTo(new THREE.Vector3(0,0,-12))<3,fieldNear=pos.distanceTo(SOCCER_CENTER)<12;$('act').hidden=busy||!(doorNear||fieldNear);$('act').textContent=doorNear?'🚪 ورود به کلاس (E)':'⚽ فوتبال سه به سه (E)';if(input.act&&!busy){input.act=false;if(doorNear)enterClass();else if(fieldNear)football3v3()}}else{const nearSeat=seat&&pos.distanceTo(seat)<1.8;$('act').hidden=busy||!nearSeat;$('act').textContent='🪑 نشستن و شروع کلاس (E)';if(input.act&&!busy&&nearSeat){input.act=false;pos.copy(seat);bookSelect()}}}
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});function homeworkUI(){const h=state.homework.length?state.homework.map(x=>'• '+x).join('<br>'):'برای امروز تکلیفی ثبت نشده.';show(`<h2>📚 تکالیف</h2><div class="info">${h}</div><button class="ok" data-close>بستن</button>`);$('box').querySelector('[data-close]').onclick=closeModal}
function termReportUI(){const rows=Object.entries(state.grades).map(([s,g])=>`<tr><td>${s}</td><td>${(g.total/g.count).toFixed(1)}</td></tr>`).join('')||'<tr><td colspan=2>هنوز نمره‌ای ثبت نشده</td></tr>';show(`<h2>🏆 کارنامه ترم</h2><div class="info">میانگین همه نمره‌های ثبت‌شده: <b>${fa(score())}</b></div><table><tr><th>درس</th><th>میانگین</th></tr>${rows}</table><button class="ok" data-close>بستن</button>`);$('box').querySelector('[data-close]').onclick=closeModal}
$('start').onclick=()=>{$('menu').classList.add('menuHide');pos.set(-24,0,62);P.yaw=-0.5754;input.yaw=-0.5754;say(`🌅 ${dayName()} — زنگ ۸ شروع شد؛ در محوطه مدرسه هستی. آماده شروع روزی تازه‌ای`)};$('menuSettings').onclick=()=>{$('menuHome').hidden=true;$('menuSettingsPanel').hidden=false};$('menuBack').onclick=()=>{$('menuSettingsPanel').hidden=true;$('menuHome').hidden=false};$('menuQuality').querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>{quality(b.dataset.q);$('menuQuality').querySelectorAll('[data-q]').forEach(x=>x.classList.toggle('active',x===b))});$('menuAbout').onclick=()=>{$('menuHome').hidden=true;$('menuAboutPanel').hidden=false};$('aboutBack').onclick=()=>{$('menuAboutPanel').hidden=true;$('menuHome').hidden=false};$('settings').onclick=settings;$('schedule').onclick=scheduleUI;$('report').onclick=reportUI;$('save').onclick=()=>{save();$('save').textContent='✅';setTimeout(()=>$('save').textContent='💾',700)};
// Add exam-history button to HUD without changing the working V7 menu layout.
const hb=document.createElement('button');hb.id='examHistory';hb.textContent='📝';hb.title='تاریخچه امتحانات';$('hud').querySelector('.hudBtns').appendChild(hb);hb.onclick=examHistoryUI;const hw=document.createElement('button');hw.id='homeworkBtn';hw.textContent='📚';hw.title='تکالیف';$('hud').querySelector('.hudBtns').appendChild(hw);hw.onclick=homeworkUI;const tr=document.createElement('button');tr.id='termBtn';tr.textContent='🏆';tr.title='کارنامه ترم';$('hud').querySelector('.hudBtns').appendChild(tr);tr.onclick=termReportUI;
async function boot(){quality(state.quality);schoolTime();$('score').textContent=fa(score());player=primitiveFallback('player');scene.add(player.pivot);player.pivot.position.copy(pos);$('loading').style.display='none';$('modal').hidden=true;$('modal').style.display='none';$('act').hidden=true;$('box').innerHTML='';loadTomCharacter().then(ok=>{if(ok&&player?.pivot?.parent){const old=player.pivot,np=makeCharacter('player');np.pivot.position.copy(old.position);np.pivot.rotation.copy(old.rotation);scene.add(np.pivot);scene.remove(old);player=np}});loadOptionalAssets();}
boot();
const clock3=new THREE.Clock(),v=new THREE.Vector3(),target=new THREE.Vector3(),desiredCam=new THREE.Vector3(),look=new THREE.Vector3();function frame(){requestAnimationFrame(frame);const dt=Math.min(clock3.getDelta(),.05),k=input.keys;const mv={x:(k.KeyD||k.ArrowRight?1:0)-(k.KeyA||k.ArrowLeft?1:0)+input.joyX,y:(k.KeyW||k.ArrowUp?1:0)-(k.KeyS||k.ArrowDown?1:0)+input.joyY};let len=Math.hypot(mv.x,mv.y);if(len>1){mv.x/=len;mv.y/=len;len=1}const running=input.run||k.ShiftLeft||k.ShiftRight,speed=running?5:2.5;if(!busy&&len>.08){const sy=Math.sin(input.yaw),cy=Math.cos(input.yaw);v.set(-sy*mv.y+cy*mv.x,0,-cy*mv.y-sy*mv.x).normalize();pos.addScaledVector(v,speed*dt);const a=Math.atan2(v.x,v.z);let d=a-P.yaw;d=Math.atan2(Math.sin(d),Math.cos(d));P.yaw+=d*Math.min(1,dt*10)}if(mode==='yard'){collide(pos,colliders,P.r);pos.x=THREE.MathUtils.clamp(pos.x,-85,85);pos.z=THREE.MathUtils.clamp(pos.z,-85,85)}else if(mode==='football'){pos.x=THREE.MathUtils.clamp(pos.x,fieldClampX0,fieldClampX1);pos.z=THREE.MathUtils.clamp(pos.z,fieldClampZ0,fieldClampZ1)}else if(roomB){pos.x=THREE.MathUtils.clamp(pos.x,roomB.x0,roomB.x1);pos.z=THREE.MathUtils.clamp(pos.z,roomB.z0+1,roomB.z1)}player.pivot.position.copy(pos);player.pivot.rotation.y=P.yaw;pose(player,!busy&&len>.08,dt,speed);if(teacher)pose(teacher,false,dt,1);if(tom)pose(tom,false,dt,1);interact();target.set(pos.x,1.15,pos.z);const cp=Math.cos(input.pitch),sp=Math.sin(input.pitch);desiredCam.set(target.x+Math.sin(input.yaw)*cp*input.dist,target.y+sp*input.dist+.25,target.z+Math.cos(input.yaw)*cp*input.dist);if(mode==='room'&&roomB){desiredCam.x=THREE.MathUtils.clamp(desiredCam.x,roomB.x0,roomB.x1);desiredCam.z=Math.min(desiredCam.z,roomB.z1+.6);desiredCam.y=Math.min(desiredCam.y,4)}cam.position.lerp(desiredCam,1-Math.pow(.0008,dt));look.lerp(target,1-Math.pow(.0005,dt));cam.lookAt(look);sun.position.set(pos.x+25,32,pos.z+18);sun.target.position.set(pos.x,0,pos.z);if(!busy){state.time+=dt/60;if(state.time>780)state.time=780;schoolTime();$('score').textContent=fa(score())}renderer.render(scene,cam)}frame();setInterval(()=>{if(!busy)save()},10000);
